package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.DocumentProcessor
import com.example.processor.FileValidationResult
import com.example.processor.FileValidator
import com.example.processor.ProcessingTask
import com.example.processor.ProcessorType
import com.example.processor.TaskQueueManager
import com.example.service.ProcessingForegroundService
import com.example.ui.components.CompressionPresetSelector
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.components.ReorderableList
import com.example.ui.components.SaveFileDialog
import com.example.ui.theme.FuncStartGreen
import com.example.ui.theme.SectionFileIndigo

@Composable
fun DocumentScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedPdfUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var operationMode by remember { mutableStateOf("COMPRESS") } // COMPRESS, SPLIT, MERGE, TEXT_EXTRACT
    var splitMode by remember { mutableStateOf("ALL") } // ALL, RANGE
    var pageRangeInput by remember { mutableStateOf("1-3") }
    var compressionLevel by remember { mutableStateOf("MEDIUM") }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showConfirmStartDialog by remember { mutableStateOf(false) }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedPdfUris = uris
        }
    }

    val processorType = ProcessorType.HARDWARE

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = null,
                tint = SectionFileIndigo,
                modifier = Modifier.padding(end = 8.dp)
            )
            Column {
                Text(
                    text = strings.filesSectionTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SectionFileIndigo
                )
                Text(
                    text = strings.filesSectionDesc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Processor Badge
        ProcessorBadge(processorType = processorType, strings = strings)

        Spacer(modifier = Modifier.height(16.dp))

        // Operation Selector Card
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "اختر عملية المستند:", fontWeight = FontWeight.Bold)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (operationMode == "COMPRESS"),
                        onClick = { operationMode = "COMPRESS" }
                    )
                    Text(text = strings.compressPdf)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (operationMode == "SPLIT"),
                        onClick = { operationMode = "SPLIT" }
                    )
                    Text(text = strings.splitPdf)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (operationMode == "MERGE"),
                        onClick = { operationMode = "MERGE" }
                    )
                    Text(text = strings.mergePdf)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = (operationMode == "TEXT_EXTRACT"),
                        onClick = { operationMode = "TEXT_EXTRACT" }
                    )
                    Text(text = strings.extractText)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { pdfPickerLauncher.launch("application/pdf") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("select_pdf_files_button")
                ) {
                    Text(text = strings.selectFiles)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedPdfUris.isNotEmpty()) {
            ReorderableList(
                items = selectedPdfUris,
                strings = strings,
                onReorder = { selectedPdfUris = it },
                onRemove = { idx ->
                    val mutable = selectedPdfUris.toMutableList()
                    mutable.removeAt(idx)
                    selectedPdfUris = mutable
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (operationMode == "COMPRESS") {
            Text(
                text = "مستوى ضغط PDF:",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            CompressionPresetSelector(
                selectedLevel = compressionLevel,
                strings = strings,
                onLevelSelected = { compressionLevel = it }
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        if (operationMode == "SPLIT") {
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "خيارات تقسيم PDF:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = (splitMode == "ALL"),
                            onClick = { splitMode = "ALL" }
                        )
                        Text(text = strings.splitAllPages)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = (splitMode == "RANGE"),
                            onClick = { splitMode = "RANGE" }
                        )
                        Text(text = strings.splitPageRange)
                    }

                    if (splitMode == "RANGE") {
                        Spacer(modifier = Modifier.height(8.dp))
                        androidx.compose.material3.OutlinedTextField(
                            value = pageRangeInput,
                            onValueChange = { pageRangeInput = it },
                            label = { Text(strings.pageRangeLabel) },
                            placeholder = { Text(strings.pageRangeHint) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pdf_page_range_input")
                        )
                    }
                }
            }
        }

        // Start Button
        Button(
            onClick = {
                if (selectedPdfUris.isEmpty()) {
                    Toast.makeText(context, strings.selectFile, Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val validation = FileValidator.validateFileAndStorage(context, selectedPdfUris.first())
                when (validation) {
                    is FileValidationResult.Corrupted -> {
                        Toast.makeText(context, strings.corruptedFileMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    is FileValidationResult.InsufficientStorage -> {
                        Toast.makeText(context, strings.insufficientStorageMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    FileValidationResult.Valid -> {
                        showConfirmStartDialog = true
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FuncStartGreen),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_doc_processing_button")
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = strings.start, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }

    if (showConfirmStartDialog) {
        ConfirmActionDialog(
            title = strings.confirmStartTitle,
            message = strings.confirmStartMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isStartAction = true,
            onConfirm = {
                showConfirmStartDialog = false
                showSaveDialog = true
            },
            onDismiss = { showConfirmStartDialog = false }
        )
    }

    if (showSaveDialog && selectedPdfUris.isNotEmpty()) {
        val effectiveOperation = if (operationMode == "SPLIT") {
            if (splitMode == "ALL") "SPLIT_ALL" else "SPLIT_RANGE"
        } else {
            operationMode
        }

        val outExt = when (effectiveOperation) {
            "TEXT_EXTRACT" -> "txt"
            "SPLIT_ALL" -> "zip"
            else -> "pdf"
        }

        val pageIndices = if (effectiveOperation == "SPLIT_RANGE") parsePageRange(pageRangeInput) else emptyList()

        SaveFileDialog(
            initialFilename = "voda_${effectiveOperation.lowercase()}_doc",
            extension = outExt,
            strings = strings,
            onDismiss = { showSaveDialog = false },
            onConfirmSave = { finalOutputName ->
                showSaveDialog = false
                val task = ProcessingTask(
                    title = "معالجة مستند: $finalOutputName",
                    subtitle = "العملية: $effectiveOperation",
                    fileType = "DOCUMENT",
                    inputUri = selectedPdfUris.first(),
                    desiredOutputName = finalOutputName,
                    outputExtension = outExt,
                    processorType = processorType,
                    onExecute = { onProgress, onUpdateProcessor ->
                        DocumentProcessor.processDocument(
                            context = context,
                            inputUris = selectedPdfUris,
                            options = DocumentProcessor.DocumentOptions(
                                compressionLevel = compressionLevel,
                                operation = effectiveOperation,
                                targetPageIndices = pageIndices
                            ),
                            desiredOutputName = finalOutputName,
                            onProgress = onProgress,
                            onUpdateProcessor = onUpdateProcessor
                        )
                    }
                )

                TaskQueueManager.enqueueTask(context, task)
                ProcessingForegroundService.startService(context)
                Toast.makeText(context, "تمت إضافة عملية المستند إلى الطابور 🚀", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

private fun parsePageRange(input: String): List<Int> {
    if (input.isBlank()) return emptyList()
    val list = mutableListOf<Int>()
    val parts = input.split(",")
    for (p in parts) {
        val trimmed = p.trim()
        if (trimmed.contains("-")) {
            val range = trimmed.split("-")
            if (range.size == 2) {
                val start = range[0].trim().toIntOrNull()
                val end = range[1].trim().toIntOrNull()
                if (start != null && end != null && start <= end) {
                    for (i in start..end) {
                        if (i >= 1) list.add(i - 1)
                    }
                }
            }
        } else {
            val single = trimmed.toIntOrNull()
            if (single != null && single >= 1) {
                list.add(single - 1)
            }
        }
    }
    return list.distinct().sorted()
}
