package com.example.processor

import android.net.Uri
import java.io.File

enum class ProcessorType {
    HARDWARE, // ⚡ Fast Processing (Dedicated Hardware Chip / Remux)
    SOFTWARE  // 🔧 Advanced Processing (CPU Software Transcoder)
}

enum class TaskStatus {
    QUEUED,
    RUNNING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class ProcessingTask(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val subtitle: String,
    val fileType: String, // VIDEO, AUDIO, IMAGE, DOCUMENT, CONVERSION
    val inputUri: Uri,
    val desiredOutputName: String,
    val outputExtension: String,
    var progress: Float = 0f, // 0.0 to 1.0
    var status: TaskStatus = TaskStatus.QUEUED,
    var processorType: ProcessorType = ProcessorType.HARDWARE,
    var outputFile: File? = null,
    var errorLog: String? = null,
    val tempFilesToClean: MutableList<File> = mutableListOf(),
    val onExecute: suspend (onProgress: (Float) -> Unit, onUpdateProcessor: (ProcessorType) -> Unit) -> File
) {
    fun registerTempFile(file: File) {
        tempFilesToClean.add(file)
    }

    fun cleanAllTempFiles() {
        outputFile?.let {
            if (it.exists()) {
                try { it.deleteRecursively() } catch (e: Exception) {}
            }
        }
        tempFilesToClean.forEach { file ->
            if (file.exists()) {
                try { file.deleteRecursively() } catch (e: Exception) {}
            }
        }
        tempFilesToClean.clear()
    }
}
