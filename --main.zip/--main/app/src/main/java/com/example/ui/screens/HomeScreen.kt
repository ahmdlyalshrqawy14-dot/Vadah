package com.example.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.ui.components.OceanBackground
import com.example.ui.theme.SectionAudioOrange
import com.example.ui.theme.SectionConvertCyan
import com.example.ui.theme.SectionFileIndigo
import com.example.ui.theme.SectionImageTeal
import com.example.ui.theme.SectionVideoPurple

@Composable
fun HomeScreen(
    strings: AppStrings,
    onNavigateToSection: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OceanBackground(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Section 2: Main Hero Area Spacing (Vertical gap below Dynamic Island)
            Spacer(modifier = Modifier.height(34.dp))

            // Section 3: Feature Cards - Vertical Glassmorphic Stack
            GlassmorphicFeatureCard(
                title = strings.videoSectionTitle,
                desc = strings.videoSectionDesc,
                icon = Icons.Default.Movie,
                accentColor = SectionVideoPurple,
                testTag = "nav_video_card",
                onClick = { onNavigateToSection("video") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicFeatureCard(
                title = strings.audioSectionTitle,
                desc = strings.audioSectionDesc,
                icon = Icons.Default.Audiotrack,
                accentColor = SectionAudioOrange,
                testTag = "nav_audio_card",
                onClick = { onNavigateToSection("audio") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicFeatureCard(
                title = strings.imageSectionTitle,
                desc = strings.imageSectionDesc,
                icon = Icons.Default.Image,
                accentColor = SectionImageTeal,
                testTag = "nav_image_card",
                onClick = { onNavigateToSection("image") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicFeatureCard(
                title = strings.filesSectionTitle,
                desc = strings.filesSectionDesc,
                icon = Icons.Default.Description,
                accentColor = SectionFileIndigo,
                testTag = "nav_files_card",
                onClick = { onNavigateToSection("files") }
            )

            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicFeatureCard(
                title = strings.conversionSectionTitle,
                desc = strings.conversionSectionDesc,
                icon = Icons.Default.Transform,
                accentColor = SectionConvertCyan,
                testTag = "nav_convert_card",
                onClick = { onNavigateToSection("convert") }
            )

            Spacer(modifier = Modifier.height(100.dp)) // Bottom clearance for floating navbar
        }
    }
}

@Composable
private fun GlassmorphicFeatureCard(
    title: String,
    desc: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1.0f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "cardScaleAnimation"
    )

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0x99131822)), // Dark Semi-Transparent Glass
        border = BorderStroke(1.dp, Color(0x14FFFFFF)), // 1px subtle glass border
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = {
                        onClick()
                    }
                )
            }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Luxury Touch: Vertical Accent Bar on the Left Edge
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(accentColor)
            )

            Spacer(modifier = Modifier.width(16.dp))

            // Left Side: Title & Description
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color.White, // Pure White #FFFFFF
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = desc,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Normal,
                    lineHeight = 18.sp,
                    color = Color(0xFFA0AAB5), // Light Ash Grey #A0AAB5
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Side: Glowing Icon Box with Soft Radial Drop Shadow
            Box(
                modifier = Modifier.size(52.dp),
                contentAlignment = Alignment.Center
            ) {
                // Soft glowing radial backdrop behind the icon
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    accentColor.copy(alpha = 0.35f),
                                    accentColor.copy(alpha = 0.10f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Glass icon container
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(accentColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
