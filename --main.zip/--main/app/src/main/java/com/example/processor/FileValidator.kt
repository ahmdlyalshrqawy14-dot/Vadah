package com.example.processor

import android.content.Context
import android.net.Uri
import android.os.StatFs
import java.io.InputStream

sealed class FileValidationResult {
    object Valid : FileValidationResult()
    data class Corrupted(val reason: String = "Header signature mismatch") : FileValidationResult()
    data class InsufficientStorage(val requiredBytes: Long, val availableBytes: Long) : FileValidationResult()
}

object FileValidator {

    fun validateFileAndStorage(
        context: Context,
        uri: Uri,
        estimatedOutputSize: Long = 0L
    ): FileValidationResult {
        // 1. Check if Uri can be opened
        val inputStream: InputStream? = try {
            context.contentResolver.openInputStream(uri)
        } catch (e: Exception) {
            null
        }

        if (inputStream == null) {
            return FileValidationResult.Corrupted("Cannot read file stream")
        }

        // 2. Read first 16 bytes for magic number check
        val header = ByteArray(16)
        val readBytes = try {
            inputStream.use { it.read(header) }
        } catch (e: Exception) {
            -1
        }

        if (readBytes < 4) {
            return FileValidationResult.Corrupted("File is empty or corrupted")
        }

        val isValidHeader = isKnownValidHeader(header)
        if (!isValidHeader) {
            return FileValidationResult.Corrupted("Invalid file header")
        }

        // 3. Storage Check
        if (estimatedOutputSize > 0) {
            val stat = StatFs(context.filesDir.absolutePath)
            val available = stat.availableBytes
            if (available < estimatedOutputSize) {
                return FileValidationResult.InsufficientStorage(estimatedOutputSize, available)
            }
        }

        return FileValidationResult.Valid
    }

    private fun isKnownValidHeader(header: ByteArray): Boolean {
        if (header.size < 4) return false

        // PDF: %PDF
        if (header[0] == 0x25.toByte() && header[1] == 0x50.toByte() &&
            header[2] == 0x44.toByte() && header[3] == 0x46.toByte()) {
            return true
        }

        // PNG: 0x89 PNG
        if (header[0] == 0x89.toByte() && header[1] == 0x50.toByte() &&
            header[2] == 0x4E.toByte() && header[3] == 0x47.toByte()) {
            return true
        }

        // JPEG: 0xFF 0xD8 0xFF
        if (header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte()) {
            return true
        }

        // ZIP / Office Docx/Xlsx/Pptx: PK.. (0x50 0x4B 0x03 0x04)
        if (header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() &&
            header[2] == 0x03.toByte() && header[3] == 0x04.toByte()) {
            return true
        }

        // RIFF (WAV, WEBM, AVI)
        if (header[0] == 0x52.toByte() && header[1] == 0x49.toByte() &&
            header[2] == 0x46.toByte() && header[3] == 0x46.toByte()) {
            return true
        }

        // MP4 / MOV: ftyp at bytes 4-7
        if (header.size >= 8) {
            if (header[4] == 0x66.toByte() && header[5] == 0x74.toByte() &&
                header[6] == 0x79.toByte() && header[7] == 0x70.toByte()) {
                return true
            }
        }

        // MKV / WEBM: 0x1A 0x45 0xDF 0xA3
        if (header[0] == 0x1A.toByte() && header[1] == 0x45.toByte() &&
            header[2] == 0xDF.toByte() && header[3] == 0xA3.toByte()) {
            return true
        }

        // MP3 ID3
        if (header[0] == 0x49.toByte() && header[1] == 0x44.toByte() && header[2] == 0x33.toByte()) {
            return true
        }

        // MP3 raw sync frame: 0xFF 0xFB / 0xFF 0xF3
        if (header[0] == 0xFF.toByte() && (header[1].toInt() and 0xE0) == 0xE0) {
            return true
        }

        // FLAC: fLaC
        if (header[0] == 0x66.toByte() && header[1] == 0x4C.toByte() &&
            header[2] == 0x61.toByte() && header[3] == 0x63.toByte()) {
            return true
        }

        // OGG: OggS
        if (header[0] == 0x4F.toByte() && header[1] == 0x67.toByte() &&
            header[2] == 0x67.toByte() && header[3] == 0x53.toByte()) {
            return true
        }

        // General fallback if file contains readable ascii/utf bytes
        var printable = 0
        for (i in 0 until minOf(header.size, 8)) {
            val b = header[i].toInt() and 0xFF
            if (b in 32..126 || b == 9 || b == 10 || b == 13) printable++
        }
        return printable >= 4
    }
}
