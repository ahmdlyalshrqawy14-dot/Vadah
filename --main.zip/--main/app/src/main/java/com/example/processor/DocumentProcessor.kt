package com.example.processor

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object DocumentProcessor {

    data class DocumentOptions(
        val compressionLevel: String = "MEDIUM", // LIGHT, MEDIUM, HEAVY, CUSTOM
        val operation: String = "COMPRESS", // COMPRESS, SPLIT, MERGE, REORDER, TEXT_EXTRACT, PASSWORD_PROTECT, UNLOCK
        val targetPageIndices: List<Int> = emptyList(), // For split / reorder / delete pages
        val password: String = ""
    )

    suspend fun processDocument(
        context: Context,
        inputUris: List<Uri>,
        options: DocumentOptions,
        desiredOutputName: String,
        onProgress: (Float) -> Unit,
        onUpdateProcessor: (ProcessorType) -> Unit
    ): File {
        onUpdateProcessor(ProcessorType.HARDWARE)

        when (options.operation) {
            "MERGE" -> {
                val tempMerged = StorageManager.createTempFile(context, "pdf_merged", "pdf")
                mergePdfFiles(context, inputUris, tempMerged, onProgress)
                return tempMerged
            }
            "SPLIT_ALL" -> {
                val tempZip = StorageManager.createTempFile(context, "pdf_split_pages", "zip")
                splitAllPagesToZip(context, inputUris.first(), tempZip, onProgress)
                return tempZip
            }
            "SPLIT", "SPLIT_RANGE", "REORDER" -> {
                val tempSplit = StorageManager.createTempFile(context, "pdf_split", "pdf")
                splitOrReorderPdf(context, inputUris.first(), tempSplit, options.targetPageIndices, onProgress)
                return tempSplit
            }
            "TEXT_EXTRACT" -> {
                val tempTxt = StorageManager.createTempFile(context, "extracted_text", "txt")
                extractTextFromPdf(context, inputUris.first(), tempTxt, onProgress)
                return tempTxt
            }
            else -> {
                // Default COMPRESS operation
                val tempCompressed = StorageManager.createTempFile(context, "pdf_compressed", "pdf")
                compressPdfFile(context, inputUris.first(), tempCompressed, options.compressionLevel, onProgress)
                return tempCompressed
            }
        }
    }

    private suspend fun compressPdfFile(
        context: Context,
        pdfUri: Uri,
        outputFile: File,
        compressionLevel: String,
        onProgress: (Float) -> Unit
    ) {
        val pfd = context.contentResolver.openFileDescriptor(pdfUri, "r") ?: return
        val renderer = PdfRenderer(pfd)
        val pdfDoc = PdfDocument()

        val scale = when (compressionLevel) {
            "LIGHT" -> 1.5f
            "HEAVY" -> 0.8f
            else -> 1.1f // MEDIUM
        }

        val pageCount = renderer.pageCount
        for (i in 0 until pageCount) {
            val page = renderer.openPage(i)
            val bitmapW = (page.width * scale).toInt().coerceAtLeast(1)
            val bitmapH = (page.height * scale).toInt().coerceAtLeast(1)

            val bitmap = android.graphics.Bitmap.createBitmap(bitmapW, bitmapH, android.graphics.Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

            val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, i + 1).create()
            val docPage = pdfDoc.startPage(pageInfo)
            val docCanvas = docPage.canvas
            val rect = android.graphics.Rect(0, 0, page.width, page.height)
            docCanvas.drawBitmap(bitmap, null, rect, null)
            pdfDoc.finishPage(docPage)

            bitmap.recycle()
            page.close()

            onProgress(((i + 1).toFloat() / pageCount.toFloat()).coerceIn(0f, 0.99f))
            delay(10)
        }

        FileOutputStream(outputFile).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        renderer.close()
        pfd.close()
        onProgress(1.0f)
    }

    private suspend fun mergePdfFiles(
        context: Context,
        pdfUris: List<Uri>,
        outputFile: File,
        onProgress: (Float) -> Unit
    ) {
        val pdfDoc = PdfDocument()
        var pageCounter = 1

        pdfUris.forEachIndexed { pdfIndex, uri ->
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                val renderer = PdfRenderer(pfd)
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    val bitmap = android.graphics.Bitmap.createBitmap(page.width, page.height, android.graphics.Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(bitmap)
                    canvas.drawColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                    val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, pageCounter++).create()
                    val docPage = pdfDoc.startPage(pageInfo)
                    docPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdfDoc.finishPage(docPage)

                    bitmap.recycle()
                    page.close()
                }
                renderer.close()
            }
            onProgress(((pdfIndex + 1).toFloat() / pdfUris.size.toFloat()).coerceIn(0f, 0.99f))
            delay(10)
        }

        FileOutputStream(outputFile).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        onProgress(1.0f)
    }

    private suspend fun splitOrReorderPdf(
        context: Context,
        pdfUri: Uri,
        outputFile: File,
        targetPageIndices: List<Int>,
        onProgress: (Float) -> Unit
    ) {
        val pfd = context.contentResolver.openFileDescriptor(pdfUri, "r") ?: return
        val renderer = PdfRenderer(pfd)
        val pdfDoc = PdfDocument()

        val pagesToProcess = if (targetPageIndices.isNotEmpty()) targetPageIndices else (0 until renderer.pageCount).toList()

        pagesToProcess.forEachIndexed { outIndex, pageIdx ->
            if (pageIdx in 0 until renderer.pageCount) {
                val page = renderer.openPage(pageIdx)
                val bitmap = android.graphics.Bitmap.createBitmap(page.width, page.height, android.graphics.Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bitmap)
                canvas.drawColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, outIndex + 1).create()
                val docPage = pdfDoc.startPage(pageInfo)
                docPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDoc.finishPage(docPage)

                bitmap.recycle()
                page.close()
            }
            onProgress(((outIndex + 1).toFloat() / pagesToProcess.size.toFloat()).coerceIn(0f, 0.99f))
            delay(10)
        }

        FileOutputStream(outputFile).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        renderer.close()
        pfd.close()
        onProgress(1.0f)
    }

    private suspend fun extractTextFromPdf(
        context: Context,
        pdfUri: Uri,
        outputTxtFile: File,
        onProgress: (Float) -> Unit
    ) {
        val sb = StringBuilder()
        sb.append("=== Extracted Document Text (вода) ===\n\n")

        context.contentResolver.openInputStream(pdfUri)?.use { input ->
            val bytes = input.readBytes()
            val text = String(bytes, Charsets.ISO_8859_1)

            // Extract plain text blocks enclosed in parenthesis in PDF stream
            val regex = Regex("""\((.*?)\)""")
            val matches = regex.findAll(text)
            var count = 0
            for (match in matches) {
                val str = match.groupValues[1]
                if (str.length > 2 && str.any { it.isLetterOrDigit() }) {
                    sb.append(str).append(" ")
                    count++
                    if (count % 15 == 0) sb.append("\n")
                }
            }
        }

        if (sb.length < 50) {
            sb.append("\n(No unencrypted plaintext tags detected in this PDF file.)")
        }

        outputTxtFile.writeText(sb.toString())
        onProgress(1.0f)
    }

    private suspend fun splitAllPagesToZip(
        context: Context,
        pdfUri: Uri,
        outputZipFile: File,
        onProgress: (Float) -> Unit
    ) {
        val pfd = context.contentResolver.openFileDescriptor(pdfUri, "r") ?: return
        val renderer = PdfRenderer(pfd)
        val totalPages = renderer.pageCount

        ZipOutputStream(FileOutputStream(outputZipFile)).use { zos ->
            for (i in 0 until totalPages) {
                val singlePageDoc = PdfDocument()
                val page = renderer.openPage(i)

                val bitmap = android.graphics.Bitmap.createBitmap(page.width, page.height, android.graphics.Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bitmap)
                canvas.drawColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

                val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, 1).create()
                val docPage = singlePageDoc.startPage(pageInfo)
                docPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                singlePageDoc.finishPage(docPage)

                val tempPageFile = StorageManager.createTempFile(context, "page_${i + 1}", "pdf")
                FileOutputStream(tempPageFile).use { out ->
                    singlePageDoc.writeTo(out)
                }
                singlePageDoc.close()
                bitmap.recycle()
                page.close()

                val entry = ZipEntry("page_${i + 1}.pdf")
                zos.putNextEntry(entry)
                tempPageFile.inputStream().use { input ->
                    input.copyTo(zos)
                }
                zos.closeEntry()
                tempPageFile.delete()

                onProgress(((i + 1).toFloat() / totalPages.toFloat()).coerceIn(0f, 0.99f))
                delay(10)
            }
        }

        renderer.close()
        pfd.close()
        onProgress(1.0f)
    }
}
