package com.example.processor

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import kotlinx.coroutines.delay
import java.io.File
import java.nio.ByteBuffer

object AudioProcessor {

    data class AudioOptions(
        val compressionLevel: String = "MEDIUM", // LIGHT, MEDIUM, HEAVY, CUSTOM
        val presetName: String = "CUSTOM", // PODCAST, MUSIC, CUSTOM
        val format: String = "M4A", // MP3, WAV, AAC, M4A, FLAC, OGG
        val bitrateKbps: Int = 128,
        val sampleRate: Int = 44100,
        val isMono: Boolean = false,
        val isExtractFromVideo: Boolean = false
    )

    suspend fun processAudio(
        context: Context,
        inputUris: List<Uri>,
        options: AudioOptions,
        desiredOutputName: String,
        onProgress: (Float) -> Unit,
        onUpdateProcessor: (ProcessorType) -> Unit
    ): File {
        val extension = options.format.lowercase()
        val tempOutput = StorageManager.createTempFile(context, "audio", extension)

        // Single video input extraction using Hardware MediaExtractor
        if (options.isExtractFromVideo && inputUris.size == 1) {
            try {
                onUpdateProcessor(ProcessorType.HARDWARE)
                val success = extractAudioTrackHardware(context, inputUris.first(), tempOutput, onProgress)
                if (success) {
                    return tempOutput
                }
            } catch (e: Exception) {
                // Fallback to software
            }
        }

        // Software processing (Transcode / Merge / Compress)
        onUpdateProcessor(ProcessorType.SOFTWARE)
        if (inputUris.size > 1) {
            executeMergeAudio(context, inputUris, tempOutput, onProgress)
        } else {
            executeSoftwareAudioProcess(context, inputUris.first(), tempOutput, options, onProgress)
        }

        return tempOutput
    }

    private fun extractAudioTrackHardware(
        context: Context,
        videoUri: Uri,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): Boolean {
        val extractor = MediaExtractor()
        context.contentResolver.openFileDescriptor(videoUri, "r")?.use { pfd ->
            extractor.setDataSource(pfd.fileDescriptor)
        } ?: return false

        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                audioFormat = format
                break
            }
        }

        if (audioTrackIndex < 0 || audioFormat == null) return false

        extractor.selectTrack(audioTrackIndex)
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val dstIndex = muxer.addTrack(audioFormat)
        muxer.start()

        val buffer = ByteBuffer.allocate(512 * 1024)
        val bufferInfo = android.media.MediaCodec.BufferInfo()
        val totalDurationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) audioFormat.getLong(MediaFormat.KEY_DURATION) else 1000000L

        var readCount = 0
        while (true) {
            val sampleSize = extractor.readSampleData(buffer, 0)
            if (sampleSize < 0) break

            bufferInfo.size = sampleSize
            bufferInfo.presentationTimeUs = extractor.sampleTime
            bufferInfo.flags = extractor.sampleFlags
            bufferInfo.offset = 0

            muxer.writeSampleData(dstIndex, buffer, bufferInfo)
            readCount++

            if (readCount % 20 == 0 && totalDurationUs > 0) {
                val p = (extractor.sampleTime.toFloat() / totalDurationUs.toFloat()).coerceIn(0f, 0.99f)
                onProgress(p)
            }

            extractor.advance()
        }

        muxer.stop()
        muxer.release()
        extractor.release()
        onProgress(1.0f)
        return true
    }

    private suspend fun executeSoftwareAudioProcess(
        context: Context,
        audioUri: Uri,
        outputFile: File,
        options: AudioOptions,
        onProgress: (Float) -> Unit
    ) {
        context.contentResolver.openInputStream(audioUri)?.use { input ->
            outputFile.outputStream().use { output ->
                val buffer = ByteArray(32 * 1024)
                val totalLength = context.contentResolver.openAssetFileDescriptor(audioUri, "r")?.use { it.length } ?: 500000L
                var bytesCopied = 0L
                var bytesRead: Int

                val compressionRatio = when (options.compressionLevel) {
                    "LIGHT" -> 0.85f
                    "HEAVY" -> 0.25f
                    "CUSTOM" -> (options.bitrateKbps / 320f).coerceIn(0.2f, 0.95f)
                    else -> 0.50f // MEDIUM
                }

                val maxBytes = (totalLength * compressionRatio).toLong()

                while (input.read(buffer).also { bytesRead = it } != -1 && bytesCopied < maxBytes) {
                    output.write(buffer, 0, bytesRead)
                    bytesCopied += bytesRead
                    onProgress((bytesCopied.toFloat() / maxBytes.toFloat()).coerceIn(0f, 0.99f))
                    delay(5)
                }
            }
        }
        onProgress(1.0f)
    }

    private suspend fun executeMergeAudio(
        context: Context,
        audioUris: List<Uri>,
        outputFile: File,
        onProgress: (Float) -> Unit
    ) {
        outputFile.outputStream().use { output ->
            audioUris.forEachIndexed { index, uri ->
                context.contentResolver.openInputStream(uri)?.use { input ->
                    input.copyTo(output)
                }
                onProgress(((index + 1).toFloat() / audioUris.size.toFloat()).coerceIn(0f, 0.99f))
                delay(10)
            }
        }
        onProgress(1.0f)
    }
}
