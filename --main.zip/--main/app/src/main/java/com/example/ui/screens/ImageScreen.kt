package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.FileValidationResult
import com.example.processor.FileValidator
import com.example.processor.ImageProcessor
import com.example.processor.ProcessingTask
import com.example.processor.ProcessorType
import com.example.processor.TaskQueueManager
import com.example.service.ProcessingForegroundService
import com.example.ui.components.CompressionPresetSelector
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.components.ReorderableList
import com.example.ui.components.SaveFileDialog
import com.example.ui.theme.FuncStartGreen
import com.example.ui.theme.SectionImageTeal

@Composable
fun ImageScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedImageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var compressionLevel by remember { mutableStateOf("MEDIUM") }
    var isImagesToPdf by remember { mutableStateOf(false) }
    var removeExif by remember { mutableStateOf(true) }
    var selectedFormat by remember { mutableStateOf("JPEG") }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showConfirmStartDialog by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedImageUris = uris
        }
    }

    val processorType = ProcessorType.HARDWARE

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Image,
                contentDescription = null,
                tint = SectionImageTeal,
                modifier = Modifier.padding(end = 8.dp)
            )
            Column {
                Text(
                    text = strings.imageSectionTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SectionImageTeal
                )
                Text(
                    text = strings.imageSectionDesc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Processor Badge
        ProcessorBadge(processorType = processorType, strings = strings)

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Card
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isImagesToPdf,
                        onCheckedChange = { isImagesToPdf = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = strings.imagesToPdf, fontWeight = FontWeight.Bold)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = removeExif,
                        onCheckedChange = { removeExif = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = strings.removeExif, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { imagePickerLauncher.launch("image/*") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("select_images_button")
                ) {
                    Text(text = strings.selectFiles)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedImageUris.isNotEmpty()) {
            ReorderableList(
                items = selectedImageUris,
                strings = strings,
                onReorder = { selectedImageUris = it },
                onRemove = { idx ->
                    val mutable = selectedImageUris.toMutableList()
                    mutable.removeAt(idx)
                    selectedImageUris = mutable
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Compression Presets
        if (!isImagesToPdf) {
            Text(
                text = "مستوى ضغط الصور:",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            CompressionPresetSelector(
                selectedLevel = compressionLevel,
                strings = strings,
                onLevelSelected = { compressionLevel = it }
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Start Button
        Button(
            onClick = {
                if (selectedImageUris.isEmpty()) {
                    Toast.makeText(context, strings.selectFile, Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val validation = FileValidator.validateFileAndStorage(context, selectedImageUris.first())
                when (validation) {
                    is FileValidationResult.Corrupted -> {
                        Toast.makeText(context, strings.corruptedFileMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    is FileValidationResult.InsufficientStorage -> {
                        Toast.makeText(context, strings.insufficientStorageMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    FileValidationResult.Valid -> {
                        showConfirmStartDialog = true
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FuncStartGreen),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_image_processing_button")
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = strings.start, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }

    if (showConfirmStartDialog) {
        ConfirmActionDialog(
            title = strings.confirmStartTitle,
            message = strings.confirmStartMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isStartAction = true,
            onConfirm = {
                showConfirmStartDialog = false
                showSaveDialog = true
            },
            onDismiss = { showConfirmStartDialog = false }
        )
    }

    if (showSaveDialog && selectedImageUris.isNotEmpty()) {
        val outExt = if (isImagesToPdf) "pdf" else selectedFormat.lowercase()
        SaveFileDialog(
            initialFilename = if (isImagesToPdf) "images_document" else "processed_image",
            extension = outExt,
            strings = strings,
            onDismiss = { showSaveDialog = false },
            onConfirmSave = { finalOutputName ->
                showSaveDialog = false
                val task = ProcessingTask(
                    title = if (isImagesToPdf) "تجميع صور إلى PDF" else "معالجة صور: $finalOutputName",
                    subtitle = "مستوى الضغط: $compressionLevel",
                    fileType = "IMAGE",
                    inputUri = selectedImageUris.first(),
                    desiredOutputName = finalOutputName,
                    outputExtension = outExt,
                    processorType = processorType,
                    onExecute = { onProgress, onUpdateProcessor ->
                        ImageProcessor.processImage(
                            context = context,
                            inputUris = selectedImageUris,
                            options = ImageProcessor.ImageOptions(
                                compressionLevel = compressionLevel,
                                format = selectedFormat,
                                removeExif = removeExif,
                                isImagesToPdf = isImagesToPdf
                            ),
                            desiredOutputName = finalOutputName,
                            onProgress = onProgress,
                            onUpdateProcessor = onUpdateProcessor
                        )
                    }
                )

                TaskQueueManager.enqueueTask(context, task)
                ProcessingForegroundService.startService(context)
                Toast.makeText(context, "تمت إضافة عملية الصور إلى الطابور 🚀", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
