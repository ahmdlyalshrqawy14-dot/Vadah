package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.FileValidationResult
import com.example.processor.FileValidator
import com.example.processor.ProcessingTask
import com.example.processor.ProcessorType
import com.example.processor.TaskQueueManager
import com.example.processor.VideoProcessor
import com.example.service.ProcessingForegroundService
import com.example.ui.components.CompressionPresetSelector
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.components.SaveFileDialog
import com.example.ui.theme.FuncStartGreen
import com.example.ui.theme.SectionVideoPurple

@Composable
fun VideoScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedVideoName by remember { mutableStateOf("") }
    var compressionLevel by remember { mutableStateOf("MEDIUM") }
    var removeAudio by remember { mutableStateOf(false) }
    var targetFps by remember { mutableStateOf(30) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showConfirmStartDialog by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri
            selectedVideoName = uri.lastPathSegment ?: "video"
        }
    }

    val processorType = if (compressionLevel == "LIGHT") ProcessorType.HARDWARE else ProcessorType.SOFTWARE

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Movie,
                contentDescription = null,
                tint = SectionVideoPurple,
                modifier = Modifier.padding(end = 8.dp)
            )
            Column {
                Text(
                    text = strings.videoSectionTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SectionVideoPurple
                )
                Text(
                    text = strings.videoSectionDesc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Processor Badge
        ProcessorBadge(processorType = processorType, strings = strings)

        Spacer(modifier = Modifier.height(16.dp))

        // File Selection Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (selectedVideoUri != null) "الفيديو المحدد: $selectedVideoName" else strings.selectFile,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { videoPickerLauncher.launch("video/*") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("select_video_button")
                ) {
                    Text(text = strings.selectFile)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Compression Level Selector
        Text(
            text = "مستوى ضغط الفيديو:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        CompressionPresetSelector(
            selectedLevel = compressionLevel,
            strings = strings,
            onLevelSelected = { compressionLevel = it }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Options
        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = removeAudio,
                        onCheckedChange = { removeAudio = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = strings.removeAudio, fontSize = 14.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Start Button
        Button(
            onClick = {
                val uri = selectedVideoUri
                if (uri == null) {
                    Toast.makeText(context, strings.selectFile, Toast.LENGTH_SHORT).show()
                    return@Button
                }

                // File validation check
                val validation = FileValidator.validateFileAndStorage(context, uri, estimatedOutputSize = 20 * 1024 * 1024L)
                when (validation) {
                    is FileValidationResult.Corrupted -> {
                        Toast.makeText(context, strings.corruptedFileMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    is FileValidationResult.InsufficientStorage -> {
                        Toast.makeText(context, strings.insufficientStorageMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    FileValidationResult.Valid -> {
                        showConfirmStartDialog = true
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FuncStartGreen),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_video_processing_button")
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = strings.start, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }

    if (showConfirmStartDialog) {
        ConfirmActionDialog(
            title = strings.confirmStartTitle,
            message = strings.confirmStartMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isStartAction = true,
            onConfirm = {
                showConfirmStartDialog = false
                showSaveDialog = true
            },
            onDismiss = { showConfirmStartDialog = false }
        )
    }

    if (showSaveDialog && selectedVideoUri != null) {
        SaveFileDialog(
            initialFilename = "compressed_$selectedVideoName",
            extension = "mp4",
            strings = strings,
            onDismiss = { showSaveDialog = false },
            onConfirmSave = { finalOutputName ->
                showSaveDialog = false
                val task = ProcessingTask(
                    title = "ضغط فيديو: $finalOutputName",
                    subtitle = "مستوى الضغط: $compressionLevel",
                    fileType = "VIDEO",
                    inputUri = selectedVideoUri!!,
                    desiredOutputName = finalOutputName,
                    outputExtension = "mp4",
                    processorType = processorType,
                    onExecute = { onProgress, onUpdateProcessor ->
                        VideoProcessor.processVideo(
                            context = context,
                            inputUri = selectedVideoUri!!,
                            options = VideoProcessor.VideoOptions(
                                compressionLevel = compressionLevel,
                                removeAudio = removeAudio,
                                targetFps = targetFps
                            ),
                            desiredOutputName = finalOutputName,
                            onProgress = onProgress,
                            onUpdateProcessor = onUpdateProcessor
                        )
                    }
                )

                TaskQueueManager.enqueueTask(context, task)
                ProcessingForegroundService.startService(context)
                Toast.makeText(context, "تمت إضافة عملية الفيديو إلى الطابور 🚀", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
