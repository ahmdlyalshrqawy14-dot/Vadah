package com.example.processor

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object StorageManager {

    private const val FOLDER_NAME = "вода"

    /**
     * Resolves file naming conflicts automatically by appending (1)_filename.ext, (2)_filename.ext
     */
    fun resolveConflictFilename(targetDir: File, baseName: String, extension: String): String {
        val ext = if (extension.startsWith(".")) extension else ".$extension"
        var candidate = "$baseName$ext"
        var file = File(targetDir, candidate)
        var counter = 1

        while (file.exists()) {
            candidate = "($counter)_$baseName$ext"
            file = File(targetDir, candidate)
            counter++
        }

        return candidate
    }

    /**
     * Gets the mandatory 'вода' directory in public Downloads / Documents or app-accessible storage
     */
    fun getVodaStorageDir(context: Context): File {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val vodaDir = File(downloads, FOLDER_NAME)
        if (!vodaDir.exists()) {
            vodaDir.mkdirs()
        }
        if (vodaDir.exists() && vodaDir.canWrite()) {
            return vodaDir
        }

        // Fallback to Documents/вода or app external files
        val docDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val vodaDoc = File(docDir, FOLDER_NAME)
        if (!vodaDoc.exists()) {
            vodaDoc.mkdirs()
        }
        if (vodaDoc.exists() && vodaDoc.canWrite()) {
            return vodaDoc
        }

        val appDir = File(context.getExternalFilesDir(null), FOLDER_NAME)
        if (!appDir.exists()) {
            appDir.mkdirs()
        }
        return appDir
    }

    /**
     * Saves a processed temp file to the mandatory 'вода' directory with conflict resolution
     */
    fun saveOutput(
        context: Context,
        tempFile: File,
        desiredBaseName: String,
        extension: String
    ): File {
        val targetDir = getVodaStorageDir(context)
        val finalFileName = resolveConflictFilename(targetDir, desiredBaseName, extension)
        val outputFile = File(targetDir, finalFileName)

        FileInputStream(tempFile).use { input ->
            FileOutputStream(outputFile).use { output ->
                input.copyTo(output)
            }
        }

        // Also add to MediaStore if applicable for gallery visibility
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, finalFileName)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$FOLDER_NAME")
                }
                context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            }
        } catch (e: Exception) {
            // Ignore MediaStore insert errors
        }

        // Clean up temp file immediately after copying
        try {
            if (tempFile.exists()) {
                tempFile.delete()
            }
        } catch (e: Exception) {
            // ignore
        }

        return outputFile
    }

    /**
     * Creates a temporary working file in context.cacheDir
     */
    fun createTempFile(context: Context, prefix: String, extension: String): File {
        val ext = if (extension.startsWith(".")) extension else ".$extension"
        return File.createTempFile("voda_${prefix}_", ext, context.cacheDir)
    }

    /**
     * Clean all temporary files from cache
     */
    fun clearTempFiles(context: Context) {
        try {
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("voda_") || file.name.endsWith(".tmp")) {
                    file.deleteRecursively()
                }
            }
            context.externalCacheDir?.listFiles()?.forEach { file ->
                if (file.name.startsWith("voda_") || file.name.endsWith(".tmp")) {
                    file.deleteRecursively()
                }
            }
        } catch (e: Exception) {
            // ignore
        }
    }
}
