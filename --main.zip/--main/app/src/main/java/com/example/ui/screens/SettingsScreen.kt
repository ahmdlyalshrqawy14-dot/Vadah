package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppLanguage
import com.example.data.i18n.AppStrings
import com.example.data.preferences.UserPreferencesRepository
import com.example.processor.StorageManager
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ui.components.BatteryOptimizationCard
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.theme.WaterBluePrimary
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    currentLanguage: AppLanguage,
    isDarkTheme: Boolean,
    strings: AppStrings,
    prefsRepo: UserPreferencesRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val safUriString by prefsRepo.safUriFlow.collectAsState(initial = null)
    val vodaDir = StorageManager.getVodaStorageDir(context)
    var pendingLangChange by remember { mutableStateOf<AppLanguage?>(null) }

    val safFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try {
                context.contentResolver.takePersistableUriPermission(uri, flags)
            } catch (e: Exception) {
                // ignore
            }
            scope.launch {
                prefsRepo.setSafUri(uri.toString())
            }
            Toast.makeText(context, strings.safFolderActive, Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = WaterBluePrimary,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = strings.settings,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = WaterBluePrimary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Language Selector Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = strings.selectLanguage,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            if (currentLanguage != AppLanguage.ARABIC) {
                                pendingLangChange = AppLanguage.ARABIC
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (currentLanguage == AppLanguage.ARABIC) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("switch_lang_arabic_button")
                    ) {
                        Text(
                            text = "العربية (RTL)",
                            fontWeight = FontWeight.Bold,
                            color = if (currentLanguage == AppLanguage.ARABIC) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (currentLanguage != AppLanguage.ENGLISH) {
                                pendingLangChange = AppLanguage.ENGLISH
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (currentLanguage == AppLanguage.ENGLISH) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("switch_lang_english_button")
                    ) {
                        Text(
                            text = "English (LTR)",
                            fontWeight = FontWeight.Bold,
                            color = if (currentLanguage == AppLanguage.ENGLISH) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Theme Toggle Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = strings.themeMode, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        text = if (isDarkTheme) strings.darkTheme else strings.lightTheme,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = { scope.launch { prefsRepo.setDarkTheme(it) } },
                    modifier = Modifier.testTag("theme_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mandatory Storage Location Card (SAF / Scoped Storage)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = strings.currentFolderLocation, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (!safUriString.isNullOrBlank()) "SAF: $safUriString" else vodaDir.absolutePath,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { safFolderLauncher.launch(null) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("select_saf_folder_button")
                ) {
                    Text(text = strings.selectSafFolder)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.cancelSelfCleanNotice,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Battery Protection
        BatteryOptimizationCard(strings = strings)

        Spacer(modifier = Modifier.height(16.dp))

        // Clear Temp Files Button
        OutlinedButton(
            onClick = {
                StorageManager.clearTempFiles(context)
                Toast.makeText(context, strings.tempFilesCleared, Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("clear_temp_files_button")
        ) {
            Icon(Icons.Default.CleaningServices, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = strings.clearTempFiles, fontWeight = FontWeight.Bold)
        }
    }

    pendingLangChange?.let { lang ->
        ConfirmActionDialog(
            title = strings.confirmLangChangeTitle,
            message = strings.confirmLangChangeMsg,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isStartAction = true,
            onConfirm = {
                scope.launch { prefsRepo.setLanguage(lang) }
                pendingLangChange = null
            },
            onDismiss = { pendingLangChange = null }
        )
    }
}
