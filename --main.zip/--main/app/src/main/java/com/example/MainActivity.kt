package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.i18n.AppLanguage
import com.example.data.i18n.StringsArabic
import com.example.data.i18n.StringsEnglish
import com.example.data.preferences.UserPreferencesRepository
import com.example.ui.components.DynamicHeaderIsland
import com.example.ui.components.DynamicIslandNavBar
import com.example.ui.screens.AudioScreen
import com.example.ui.screens.ConversionScreen
import com.example.ui.screens.DocumentScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageScreen
import com.example.ui.screens.QueueScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VideoScreen
import com.example.ui.theme.VodaTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val prefsRepo = remember { UserPreferencesRepository(context) }

            val currentLanguage by prefsRepo.languageFlow.collectAsState(initial = AppLanguage.ARABIC)
            val isDarkTheme by prefsRepo.darkThemeFlow.collectAsState(initial = true)

            val strings = if (currentLanguage == AppLanguage.ARABIC) StringsArabic else StringsEnglish

            CompositionLocalProvider(LocalLayoutDirection provides currentLanguage.layoutDirection) {
                VodaTheme(darkTheme = isDarkTheme) {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route ?: "home"

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            DynamicHeaderIsland(
                                currentRoute = currentRoute,
                                strings = strings,
                                onNavigate = { targetRoute ->
                                    if (currentRoute != targetRoute) {
                                        navController.navigate(targetRoute) {
                                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            )
                        },
                        bottomBar = {
                            DynamicIslandNavBar(
                                currentRoute = currentRoute,
                                strings = strings,
                                onNavigate = { targetRoute ->
                                    if (currentRoute != targetRoute) {
                                        navController.navigate(targetRoute) {
                                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            )
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "home",
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable("home") {
                                HomeScreen(
                                    strings = strings,
                                    onNavigateToSection = { route -> navController.navigate(route) }
                                )
                            }
                            composable("video") { VideoScreen(strings = strings) }
                            composable("audio") { AudioScreen(strings = strings) }
                            composable("image") { ImageScreen(strings = strings) }
                            composable("files") { DocumentScreen(strings = strings) }
                            composable("convert") { ConversionScreen(strings = strings) }
                            composable("queue") { QueueScreen(strings = strings) }
                            composable("history") { HistoryScreen(strings = strings) }
                            composable("settings") {
                                SettingsScreen(
                                    currentLanguage = currentLanguage,
                                    isDarkTheme = isDarkTheme,
                                    strings = strings,
                                    prefsRepo = prefsRepo
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
