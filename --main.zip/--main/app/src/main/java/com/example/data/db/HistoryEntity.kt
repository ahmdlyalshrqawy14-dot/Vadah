package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history_items")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val fileType: String, // VIDEO, AUDIO, IMAGE, DOCUMENT, CONVERSION
    val operationName: String,
    val originalSize: Long,
    val processedSize: Long,
    val outputPath: String,
    val timestamp: Long = System.currentTimeMillis(),
    val processorType: String, // HARDWARE, SOFTWARE
    val status: String = "COMPLETED",
    val errorMessage: String? = null
)
