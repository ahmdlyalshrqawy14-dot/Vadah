package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.ui.theme.FuncCancelRed
import com.example.ui.theme.FuncSaveBlue

@Composable
fun SaveFileDialog(
    initialFilename: String,
    extension: String,
    strings: AppStrings,
    onDismiss: () -> Unit,
    onConfirmSave: (finalName: String) -> Unit
) {
    var fileName by remember { mutableStateOf(initialFilename.ifEmpty { "voda_output" }) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = strings.saveDialogTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text(strings.saveDialogFilenameLabel) },
                    suffix = { Text(".$extension") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_filename_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = strings.saveFolderNotice,
                    fontSize = 12.sp,
                    color = FuncSaveBlue,
                    fontWeight = FontWeight.Medium
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmSave(fileName.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = FuncSaveBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_save_button")
            ) {
                Text(text = strings.download, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_save_button")
            ) {
                Text(text = strings.cancel, color = FuncCancelRed)
            }
        }
    )
}
