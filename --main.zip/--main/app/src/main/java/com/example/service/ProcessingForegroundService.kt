package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.processor.ProcessorType
import com.example.processor.TaskQueueManager
import com.example.processor.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProcessingForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var collectorJob: Job? = null

    companion object {
        const val CHANNEL_ID = "voda_processing_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_CANCEL = "com.example.voda.ACTION_CANCEL"
        const val ACTION_PAUSE_RESUME = "com.example.voda.ACTION_PAUSE_RESUME"

        fun startService(context: Context) {
            val intent = Intent(context, ProcessingForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, ProcessingForegroundService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        observeQueue()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                val current = TaskQueueManager.currentTask.value
                if (current != null) {
                    TaskQueueManager.cancelTask(current.id)
                }
            }
            ACTION_PAUSE_RESUME -> {
                val current = TaskQueueManager.currentTask.value
                if (current != null) {
                    if (current.status == TaskStatus.RUNNING) {
                        TaskQueueManager.pauseTask(current.id)
                    } else if (current.status == TaskStatus.PAUSED) {
                        TaskQueueManager.resumeTask(current.id)
                    }
                }
            }
        }

        val notification = buildNotification("вода - جاهز للمعالجة", "في انتظار العمليات...", 0, ProcessorType.HARDWARE, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        return START_STICKY
    }

    private fun observeQueue() {
        collectorJob = serviceScope.launch {
            TaskQueueManager.currentTask.collectLatest { task ->
                if (task != null) {
                    val title = task.title
                    val progressInt = (task.progress * 100).toInt()
                    val isPaused = (task.status == TaskStatus.PAUSED)
                    val statusText = if (isPaused) "موقوف مؤقتاً ⏸️" else "جاري المعالجة $progressInt%..."
                    val notification = buildNotification(title, statusText, progressInt, task.processorType, isPaused)
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    manager.notify(NOTIFICATION_ID, notification)
                } else {
                    val notification = buildNotification("вода - اكتملت العمليات ✅", "جميع المهام في الطابور انتهت بنجاح.", 100, ProcessorType.HARDWARE, false)
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    manager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    private fun buildNotification(
        title: String,
        contentText: String,
        progress: Int,
        processorType: ProcessorType,
        isPaused: Boolean
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(this, ProcessingForegroundService::class.java).apply {
            action = ACTION_CANCEL
        }
        val pendingCancel = PendingIntent.getService(
            this, 1, cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeIntent = Intent(this, ProcessingForegroundService::class.java).apply {
            action = ACTION_PAUSE_RESUME
        }
        val pendingPauseResume = PendingIntent.getService(
            this, 2, pauseResumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val badgeStr = if (processorType == ProcessorType.HARDWARE) "⚡ الهاردوير" else "🔧 السوفتوير"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("$title ($badgeStr)")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setProgress(100, progress, progress == 0)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إلغاء", pendingCancel)
            .addAction(
                if (isPaused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
                if (isPaused) "استئناف" else "إيقاف مؤقت",
                pendingPauseResume
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "вода Processing Channel"
            val descriptionText = "Notifications for local media and document processing"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "вода::ProcessingWakeLock").apply {
            acquire(30 * 60 * 1000L) // 30 mins timeout max
        }
    }

    override fun onDestroy() {
        collectorJob?.cancel()
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
