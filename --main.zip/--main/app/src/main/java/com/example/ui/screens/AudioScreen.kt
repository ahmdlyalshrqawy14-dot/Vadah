package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.AudioProcessor
import com.example.processor.FileValidationResult
import com.example.processor.FileValidator
import com.example.processor.ProcessingTask
import com.example.processor.ProcessorType
import com.example.processor.TaskQueueManager
import com.example.service.ProcessingForegroundService
import com.example.ui.components.CompressionPresetSelector
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.components.ReorderableList
import com.example.ui.components.SaveFileDialog
import com.example.ui.theme.FuncStartGreen
import com.example.ui.theme.SectionAudioOrange

@Composable
fun AudioScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedAudioUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isExtractFromVideo by remember { mutableStateOf(false) }
    var compressionLevel by remember { mutableStateOf("MEDIUM") }
    var selectedFormat by remember { mutableStateOf("M4A") }
    var showSaveDialog by remember { mutableStateOf(false) }
    var showConfirmStartDialog by remember { mutableStateOf(false) }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedAudioUris = uris
        }
    }

    val videoForAudioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedAudioUris = listOf(uri)
            isExtractFromVideo = true
        }
    }

    val processorType = if (isExtractFromVideo) ProcessorType.HARDWARE else ProcessorType.SOFTWARE

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Audiotrack,
                contentDescription = null,
                tint = SectionAudioOrange,
                modifier = Modifier.padding(end = 8.dp)
            )
            Column {
                Text(
                    text = strings.audioSectionTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SectionAudioOrange
                )
                Text(
                    text = strings.audioSectionDesc,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Processor Badge
        ProcessorBadge(processorType = processorType, strings = strings)

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Options
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isExtractFromVideo,
                        onCheckedChange = { isExtractFromVideo = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = strings.extractFromVideo, fontWeight = FontWeight.Medium)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        if (isExtractFromVideo) {
                            videoForAudioPickerLauncher.launch("video/*")
                        } else {
                            audioPickerLauncher.launch("audio/*")
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("select_audio_file_button")
                ) {
                    Text(text = if (isExtractFromVideo) "اختر ملف فيديو لاستخراج الصوت" else strings.selectFiles)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected files list
        if (selectedAudioUris.isNotEmpty()) {
            ReorderableList(
                items = selectedAudioUris,
                strings = strings,
                onReorder = { selectedAudioUris = it },
                onRemove = { idx ->
                    val mutable = selectedAudioUris.toMutableList()
                    mutable.removeAt(idx)
                    selectedAudioUris = mutable
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Compression Presets
        Text(
            text = "مستوى ضغط الصوت:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        CompressionPresetSelector(
            selectedLevel = compressionLevel,
            strings = strings,
            onLevelSelected = { compressionLevel = it }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Start Button
        Button(
            onClick = {
                if (selectedAudioUris.isEmpty()) {
                    Toast.makeText(context, strings.selectFile, Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val firstUri = selectedAudioUris.first()
                val validation = FileValidator.validateFileAndStorage(context, firstUri)
                when (validation) {
                    is FileValidationResult.Corrupted -> {
                        Toast.makeText(context, strings.corruptedFileMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    is FileValidationResult.InsufficientStorage -> {
                        Toast.makeText(context, strings.insufficientStorageMsg, Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    FileValidationResult.Valid -> {
                        showConfirmStartDialog = true
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FuncStartGreen),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("start_audio_processing_button")
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = strings.start, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }

    if (showConfirmStartDialog) {
        ConfirmActionDialog(
            title = strings.confirmStartTitle,
            message = strings.confirmStartMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isStartAction = true,
            onConfirm = {
                showConfirmStartDialog = false
                showSaveDialog = true
            },
            onDismiss = { showConfirmStartDialog = false }
        )
    }

    if (showSaveDialog && selectedAudioUris.isNotEmpty()) {
        SaveFileDialog(
            initialFilename = if (isExtractFromVideo) "extracted_audio" else "processed_audio",
            extension = selectedFormat.lowercase(),
            strings = strings,
            onDismiss = { showSaveDialog = false },
            onConfirmSave = { finalOutputName ->
                showSaveDialog = false
                val task = ProcessingTask(
                    title = "معالجة صوت: $finalOutputName",
                    subtitle = if (isExtractFromVideo) "استخراج صوت من فيديو" else "ضغط / تحويل صوت",
                    fileType = "AUDIO",
                    inputUri = selectedAudioUris.first(),
                    desiredOutputName = finalOutputName,
                    outputExtension = selectedFormat.lowercase(),
                    processorType = processorType,
                    onExecute = { onProgress, onUpdateProcessor ->
                        AudioProcessor.processAudio(
                            context = context,
                            inputUris = selectedAudioUris,
                            options = AudioProcessor.AudioOptions(
                                compressionLevel = compressionLevel,
                                format = selectedFormat,
                                isExtractFromVideo = isExtractFromVideo
                            ),
                            desiredOutputName = finalOutputName,
                            onProgress = onProgress,
                            onUpdateProcessor = onUpdateProcessor
                        )
                    }
                )

                TaskQueueManager.enqueueTask(context, task)
                ProcessingForegroundService.startService(context)
                Toast.makeText(context, "تمت إضافة عملية الصوت إلى الطابور 🚀", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
