package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Semantic Function Colors
val FuncCancelRed = Color(0xFFE53935)
val FuncStartGreen = Color(0xFF43A047)
val FuncPauseAmber = Color(0xFFFFB300)
val FuncSaveBlue = Color(0xFF1E88E5)
val FuncDisabledGray = Color(0xFF9E9E9E)

// Section Accent Colors (Neon Glowing Palette)
val SectionVideoPurple = Color(0xFFB28DFF)
val SectionAudioOrange = Color(0xFFFFA62B)
val SectionImageTeal = Color(0xFF00E676)
val SectionFileIndigo = Color(0xFFFF4B72)
val SectionConvertCyan = Color(0xFF00D2FF)
val SectionConvertMagenta = Color(0xFF00D2FF) // Alias for backwards compatibility

// Water Branding Palette (вода) - Deep Luxury Ocean Theme
val WaterBluePrimary = Color(0xFF00D2FF)
val WaterBlueSecondary = Color(0xFF00B4D8)
val WaterCyanTertiary = Color(0xFF00E5FF)
val OceanGoldAccent = Color(0xFFFFD700)

// Light Mode Colors
val LightBackground = Color(0xFFF4F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2EDF8)
val LightOnSurface = Color(0xFF0B0E14)

// Dark Mode Colors (Ultra-Premium Midnight Abyss)
val DarkBackground = Color(0xFF0B0E14)       // Rich Deep Midnight Black
val DarkSurface = Color(0xFF131822)          // Dark Glass Card Base Surface
val DarkSurfaceVariant = Color(0xFF1B2230)   // Elevated Glass Border/Variant
val DarkOnSurface = Color(0xFFFFFFFF)        // Crisp Pure White Title Text
val TextSubGrey = Color(0xFFA0AAB5)          // Soft Light Ash Grey Description Text
val AccentTeal = Color(0xFF00D2FF)           // Primary Brand Cyan
val AccentTealVariant = Color(0xFF00E5FF)    // Bright Water Cyan Accent
