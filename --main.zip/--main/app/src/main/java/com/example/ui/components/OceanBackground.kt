package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.LightBackground
import com.example.ui.theme.OceanGoldAccent
import com.example.ui.theme.WaterBluePrimary
import com.example.ui.theme.WaterBlueSecondary
import com.example.ui.theme.WaterCyanTertiary

@Composable
fun OceanBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val infiniteTransition = rememberInfiniteTransition(label = "oceanWaveTransition")

    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveOffset"
    )

    val rippleScale by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rippleScale"
    )

    Box(modifier = modifier.fillMaxSize()) {
        // Deep Sea Atmospheric Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Sky Blue Gradient Base Background
            val baseGradient = if (isDark) {
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0B0E14), // Deep Midnight Black
                        Color(0xFF070A0F), // Infinite Abyss
                        Color(0xFF0B0E14)  // Rich Midnight Canvas
                    )
                )
            } else {
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE0F2FE), // Light Sky Blue Top
                        Color(0xFFBAE6FD), // Sky Blue Mid
                        Color(0xFFDBEAFE)  // Soft Azure Sky
                    )
                )
            }
            drawRect(brush = baseGradient)

            // Subtle Sky Cloud Motifs (In selected parts of the background)
            val cloudColor = if (isDark) Color.White.copy(alpha = 0.04f) else Color.White.copy(alpha = 0.45f)
            
            // Cloud Cluster 1: Top Left
            drawCloud(this, width * 0.15f, height * 0.08f, 1.2f, cloudColor)
            // Cloud Cluster 2: Top Right (Behind Ripple)
            drawCloud(this, width * 0.82f, height * 0.14f, 1.5f, cloudColor)
            // Cloud Cluster 3: Lower Mid Left
            drawCloud(this, width * 0.08f, height * 0.45f, 1.0f, cloudColor)
            // Cloud Cluster 4: Mid Right
            drawCloud(this, width * 0.90f, height * 0.72f, 1.3f, cloudColor)

            // Organic Water Wave 1
            val path1 = Path().apply {
                moveTo(0f, height * 0.15f)
                var x = 0f
                while (x <= width) {
                    val y = (height * 0.15f) + Math.sin((x / width * 4 * Math.PI) + waveOffset).toFloat() * 25f
                    lineTo(x, y)
                    x += 20f
                }
                lineTo(width, height)
                lineTo(0f, height)
                close()
            }
            drawPath(
                path = path1,
                color = if (isDark) WaterBluePrimary.copy(alpha = 0.07f) else WaterBlueSecondary.copy(alpha = 0.08f)
            )

            // Organic Water Wave 2 (Opposite Flow)
            val path2 = Path().apply {
                moveTo(0f, height * 0.65f)
                var x = 0f
                while (x <= width) {
                    val y = (height * 0.65f) + Math.cos((x / width * 3 * Math.PI) - waveOffset * 0.8f).toFloat() * 35f
                    lineTo(x, y)
                    x += 20f
                }
                lineTo(width, height)
                lineTo(0f, height)
                close()
            }
            drawPath(
                path = path2,
                color = if (isDark) WaterCyanTertiary.copy(alpha = 0.05f) else WaterBluePrimary.copy(alpha = 0.06f)
            )

            // Deep Sea Concentric Water Droplet Ripple Rings
            val centerX = width * 0.85f
            val centerY = height * 0.2f
            val maxRadius = width * 0.4f * rippleScale

            drawCircle(
                color = (if (isDark) WaterCyanTertiary else WaterBluePrimary).copy(alpha = (1.5f - rippleScale).coerceIn(0f, 0.12f)),
                radius = maxRadius,
                center = androidx.compose.ui.geometry.Offset(centerX, centerY),
                style = Stroke(width = 2f)
            )

            drawCircle(
                color = OceanGoldAccent.copy(alpha = (1.5f - rippleScale).coerceIn(0f, 0.08f)),
                radius = maxRadius * 0.6f,
                center = androidx.compose.ui.geometry.Offset(centerX, centerY),
                style = Stroke(width = 1.5f)
            )
        }

        content()
    }
}

private fun drawCloud(
    scope: DrawScope,
    centerX: Float,
    centerY: Float,
    scale: Float,
    color: Color
) {
    with(scope) {
        val r = 24f * scale
        // Overlapping soft cloud circles forming organic cloud shape
        drawCircle(color = color, radius = r * 1.3f, center = Offset(centerX, centerY))
        drawCircle(color = color, radius = r * 0.95f, center = Offset(centerX - r * 1.2f, centerY + r * 0.2f))
        drawCircle(color = color, radius = r * 0.9f, center = Offset(centerX + r * 1.2f, centerY + r * 0.25f))
        drawCircle(color = color, radius = r * 0.75f, center = Offset(centerX - r * 1.9f, centerY + r * 0.4f))
        drawCircle(color = color, radius = r * 0.8f, center = Offset(centerX + r * 1.9f, centerY + r * 0.45f))
    }
}
