package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.ProcessorType
import com.example.ui.theme.FuncStartGreen
import com.example.ui.theme.SectionVideoPurple

@Composable
fun ProcessorBadge(
    processorType: ProcessorType,
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    var showInfoDialog by remember { mutableStateOf(false) }

    val isHardware = (processorType == ProcessorType.HARDWARE)
    val badgeBg = if (isHardware) FuncStartGreen.copy(alpha = 0.12f) else SectionVideoPurple.copy(alpha = 0.12f)
    val badgeContentColor = if (isHardware) FuncStartGreen else SectionVideoPurple
    val badgeTitle = if (isHardware) strings.hardwareBadgeTitle else strings.softwareBadgeTitle

    Surface(
        color = badgeBg,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .testTag("processor_badge")
            .clip(RoundedCornerShape(12.dp))
            .clickable { showInfoDialog = true }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isHardware) Icons.Default.FlashOn else Icons.Default.Build,
                contentDescription = null,
                tint = badgeContentColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = badgeTitle,
                color = badgeContentColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Details",
                tint = badgeContentColor.copy(alpha = 0.7f),
                modifier = Modifier.size(14.dp)
            )
        }
    }

    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = {
                Text(
                    text = if (isHardware) strings.hardwareBadgeTitle else strings.softwareBadgeTitle,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = if (isHardware) strings.hardwareBadgeDesc else strings.softwareBadgeDesc,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.size(12.dp))
                    Text(
                        text = strings.offlineGuarantee,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text("OK")
                }
            }
        )
    }
}
