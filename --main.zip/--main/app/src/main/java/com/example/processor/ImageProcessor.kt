package com.example.processor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.delay
import java.io.File
import java.io.FileOutputStream

object ImageProcessor {

    data class ImageOptions(
        val compressionLevel: String = "MEDIUM", // LIGHT, MEDIUM, HEAVY, CUSTOM
        val quality: Int = 75,
        val format: String = "JPEG", // JPEG, PNG, WEBP
        val resizePercent: Int = 100, // 100%, 75%, 50%, 25%
        val removeExif: Boolean = true,
        val targetSizeMb: Float = 0f,
        val isImagesToPdf: Boolean = false,
        val isPdfToImages: Boolean = false
    )

    suspend fun processImage(
        context: Context,
        inputUris: List<Uri>,
        options: ImageOptions,
        desiredOutputName: String,
        onProgress: (Float) -> Unit,
        onUpdateProcessor: (ProcessorType) -> Unit
    ): File {
        // Images -> PDF
        if (options.isImagesToPdf) {
            onUpdateProcessor(ProcessorType.HARDWARE)
            val tempPdf = StorageManager.createTempFile(context, "images_pdf", "pdf")
            convertImagesToPdf(context, inputUris, tempPdf, onProgress)
            return tempPdf
        }

        // PDF -> Images (Extract first or all pages)
        if (options.isPdfToImages && inputUris.isNotEmpty()) {
            onUpdateProcessor(ProcessorType.HARDWARE)
            val tempImg = StorageManager.createTempFile(context, "pdf_page", options.format.lowercase())
            extractPdfToImage(context, inputUris.first(), tempImg, options.format, onProgress)
            return tempImg
        }

        // Standard Single/Batch Image Processing
        onUpdateProcessor(ProcessorType.HARDWARE)
        val ext = when (options.format.uppercase()) {
            "PNG" -> "png"
            "WEBP" -> "webp"
            else -> "jpg"
        }
        val tempOutput = StorageManager.createTempFile(context, "img", ext)
        executeImageCompression(context, inputUris.first(), tempOutput, options, onProgress)
        return tempOutput
    }

    private suspend fun executeImageCompression(
        context: Context,
        imageUri: Uri,
        outputFile: File,
        options: ImageOptions,
        onProgress: (Float) -> Unit
    ) {
        onProgress(0.2f)

        // 1. Decode bounds first
        val optionsBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(imageUri)?.use {
            BitmapFactory.decodeStream(it, null, optionsBounds)
        }

        val originalW = optionsBounds.outWidth
        val originalH = optionsBounds.outHeight

        // 2. Calculate sample size for memory safety
        val scale = (options.resizePercent / 100f).coerceIn(0.1f, 1.0f)
        val sampleSize = calculateInSampleSize(originalW, originalH, (originalW * scale).toInt(), (originalH * scale).toInt())

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }

        onProgress(0.4f)
        var bitmap = context.contentResolver.openInputStream(imageUri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: throw IllegalArgumentException("Cannot decode image")

        if (scale < 1.0f && scale > 0f) {
            val targetW = (bitmap.width * scale).toInt().coerceAtLeast(1)
            val targetH = (bitmap.height * scale).toInt().coerceAtLeast(1)
            bitmap = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
        }

        onProgress(0.7f)

        // 3. Quality selection
        var finalQuality = when (options.compressionLevel) {
            "LIGHT" -> 90
            "HEAVY" -> 40
            "CUSTOM" -> options.quality
            else -> 65 // MEDIUM
        }

        val compressFormat = when (options.format.uppercase()) {
            "PNG" -> Bitmap.CompressFormat.PNG
            "WEBP" -> if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
            else -> Bitmap.CompressFormat.JPEG
        }

        // Target size adjustment loop if targetSizeMb > 0
        if (options.targetSizeMb > 0f && compressFormat != Bitmap.CompressFormat.PNG) {
            val targetBytes = (options.targetSizeMb * 1024 * 1024).toLong()
            var tempBytes = ByteArray(0)
            while (finalQuality > 10) {
                val stream = java.io.ByteArrayOutputStream()
                bitmap.compress(compressFormat, finalQuality, stream)
                tempBytes = stream.toByteArray()
                if (tempBytes.size <= targetBytes) break
                finalQuality -= 10
            }
        }

        FileOutputStream(outputFile).use { out ->
            bitmap.compress(compressFormat, finalQuality, out)
        }

        bitmap.recycle()
        onProgress(1.0f)
    }

    private suspend fun convertImagesToPdf(
        context: Context,
        imageUris: List<Uri>,
        outputPdfFile: File,
        onProgress: (Float) -> Unit
    ) {
        val pdfDoc = PdfDocument()

        imageUris.forEachIndexed { index, uri ->
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream) ?: return@use
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                val page = pdfDoc.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDoc.finishPage(page)
                bitmap.recycle()
            }
            onProgress(((index + 1).toFloat() / imageUris.size.toFloat()).coerceIn(0f, 0.99f))
            delay(10)
        }

        FileOutputStream(outputPdfFile).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()
        onProgress(1.0f)
    }

    private fun extractPdfToImage(
        context: Context,
        pdfUri: Uri,
        outputImgFile: File,
        format: String,
        onProgress: (Float) -> Unit
    ) {
        val pfd = context.contentResolver.openFileDescriptor(pdfUri, "r") ?: return
        val renderer = PdfRenderer(pfd)
        if (renderer.pageCount == 0) {
            renderer.close()
            pfd.close()
            return
        }

        val page = renderer.openPage(0) // First page
        val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

        val compressFormat = if (format.uppercase() == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        FileOutputStream(outputImgFile).use { out ->
            bitmap.compress(compressFormat, 85, out)
        }

        bitmap.recycle()
        page.close()
        renderer.close()
        pfd.close()
        onProgress(1.0f)
    }

    private fun calculateInSampleSize(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }
}
