package com.example.processor

import android.content.Context
import com.example.data.db.AppDatabase
import com.example.data.db.HistoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class IslandEvent {
    IDLE,
    PROCESSING,
    SUCCESS,
    ERROR
}

data class IslandState(
    val event: IslandEvent = IslandEvent.IDLE,
    val taskTitle: String = "",
    val progress: Float = 0f,
    val errorMessage: String = ""
)

object TaskQueueManager {

    private val scope = CoroutineScope(Dispatchers.Default)
    private var processingJob: Job? = null

    private val _queue = MutableStateFlow<List<ProcessingTask>>(emptyList())
    val queue: StateFlow<List<ProcessingTask>> = _queue.asStateFlow()

    private val _currentTask = MutableStateFlow<ProcessingTask?>(null)
    val currentTask: StateFlow<ProcessingTask?> = _currentTask.asStateFlow()

    private val _islandState = MutableStateFlow(IslandState())
    val islandState: StateFlow<IslandState> = _islandState.asStateFlow()

    fun enqueueTask(context: Context, task: ProcessingTask) {
        _queue.value = _queue.value + task
        processNextIfNeeded(context.applicationContext)
    }

    fun cancelTask(taskId: String) {
        val list = _queue.value.toMutableList()
        val index = list.indexOfFirst { it.id == taskId }
        if (index != -1) {
            val t = list[index]
            t.status = TaskStatus.CANCELLED
            t.cleanAllTempFiles() // Immediate cleanup of all partial and temp files
            list.removeAt(index)
            _queue.value = list
            if (_currentTask.value?.id == taskId) {
                processingJob?.cancel()
                _currentTask.value = null
            }
        }
    }

    fun pauseTask(taskId: String) {
        val t = _currentTask.value
        if (t?.id == taskId && t.status == TaskStatus.RUNNING) {
            t.status = TaskStatus.PAUSED
            _currentTask.value = t
        }
    }

    fun resumeTask(taskId: String) {
        val t = _currentTask.value
        if (t?.id == taskId && t.status == TaskStatus.PAUSED) {
            t.status = TaskStatus.RUNNING
            _currentTask.value = t
        }
    }

    private fun processNextIfNeeded(context: Context) {
        if (_currentTask.value != null) return // Already running a task sequentially

        val pending = _queue.value.firstOrNull { it.status == TaskStatus.QUEUED } ?: return
        _currentTask.value = pending
        pending.status = TaskStatus.RUNNING
        _islandState.value = IslandState(IslandEvent.PROCESSING, pending.title, 0f)

        processingJob = scope.launch {
            try {
                var currentProcessor = pending.processorType
                val resultFile = pending.onExecute(
                    { progress ->
                        pending.progress = progress
                        _currentTask.value = pending
                        _islandState.value = IslandState(IslandEvent.PROCESSING, pending.title, progress)
                    },
                    { newProcessor ->
                        currentProcessor = newProcessor
                        pending.processorType = newProcessor
                        _currentTask.value = pending
                    }
                )

                // Save to 'вода' dir
                val savedFile = StorageManager.saveOutput(
                    context,
                    resultFile,
                    pending.desiredOutputName,
                    pending.outputExtension
                )

                pending.outputFile = savedFile
                pending.status = TaskStatus.COMPLETED
                pending.progress = 1.0f
                _currentTask.value = pending
                _islandState.value = IslandState(IslandEvent.SUCCESS, pending.title, 1.0f)

                // Schedule auto-reset to IDLE after 3.5s
                scope.launch {
                    kotlinx.coroutines.delay(3500)
                    if (_islandState.value.event == IslandEvent.SUCCESS) {
                        _islandState.value = IslandState(IslandEvent.IDLE)
                    }
                }

                // Record history item in Room
                val db = AppDatabase.getDatabase(context)
                val originalSize = try {
                    context.contentResolver.openAssetFileDescriptor(pending.inputUri, "r")?.use { it.length } ?: 0L
                } catch (e: Exception) { 0L }

                db.historyDao().insert(
                    HistoryEntity(
                        fileName = savedFile.name,
                        fileType = pending.fileType,
                        operationName = pending.title,
                        originalSize = originalSize,
                        processedSize = savedFile.length(),
                        outputPath = savedFile.absolutePath,
                        processorType = currentProcessor.name,
                        status = "COMPLETED"
                    )
                )

            } catch (e: kotlinx.coroutines.CancellationException) {
                pending.status = TaskStatus.CANCELLED
                pending.cleanAllTempFiles()
                _islandState.value = IslandState(IslandEvent.IDLE)
            } catch (e: Exception) {
                pending.status = TaskStatus.FAILED
                pending.errorLog = e.localizedMessage ?: e.toString()
                pending.cleanAllTempFiles()
                _currentTask.value = pending
                _islandState.value = IslandState(IslandEvent.ERROR, pending.title, 0f, pending.errorLog ?: "")

                // Schedule auto-reset to IDLE after 4s
                scope.launch {
                    kotlinx.coroutines.delay(4000)
                    if (_islandState.value.event == IslandEvent.ERROR) {
                        _islandState.value = IslandState(IslandEvent.IDLE)
                    }
                }

                val db = AppDatabase.getDatabase(context)
                db.historyDao().insert(
                    HistoryEntity(
                        fileName = pending.desiredOutputName,
                        fileType = pending.fileType,
                        operationName = pending.title,
                        originalSize = 0L,
                        processedSize = 0L,
                        outputPath = "",
                        processorType = pending.processorType.name,
                        status = "FAILED",
                        errorMessage = pending.errorLog
                    )
                )
            } finally {
                if (pending.status == TaskStatus.CANCELLED) {
                    pending.cleanAllTempFiles()
                }
                // Remove from queue and run next
                _queue.value = _queue.value.filter { it.id != pending.id }
                _currentTask.value = null
                processNextIfNeeded(context)
            }
        }
    }
}
