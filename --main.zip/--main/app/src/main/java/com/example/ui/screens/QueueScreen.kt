package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppStrings
import com.example.processor.TaskQueueManager
import com.example.processor.TaskStatus
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ErrorLogDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.theme.FuncCancelRed
import com.example.ui.theme.FuncPauseAmber
import com.example.ui.theme.WaterBluePrimary

@Composable
fun QueueScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val queue by TaskQueueManager.queue.collectAsState()
    val currentTask by TaskQueueManager.currentTask.collectAsState()
    var selectedErrorLog by remember { mutableStateOf<String?>(null) }
    var taskToCancelId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Section Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.ListAlt,
                contentDescription = null,
                tint = WaterBluePrimary,
                modifier = Modifier.padding(end = 8.dp)
            )
            Column {
                Text(
                    text = strings.queue,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = WaterBluePrimary
                )
                Text(
                    text = "طابور العمليات التسلسلي (Sequential Task Queue)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (currentTask == null && queue.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = strings.noItems,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                // Active Running Task
                currentTask?.let { task ->
                    item {
                        Text(
                            text = "العملية الجارية حالياً:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                                .testTag("active_queue_task_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = task.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    ProcessorBadge(processorType = task.processorType, strings = strings)
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = task.subtitle,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                LinearProgressIndicator(
                                    progress = { task.progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp),
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Pause / Resume
                                    IconButton(
                                        onClick = {
                                            if (task.status == TaskStatus.RUNNING) {
                                                TaskQueueManager.pauseTask(task.id)
                                            } else {
                                                TaskQueueManager.resumeTask(task.id)
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (task.status == TaskStatus.PAUSED) Icons.Default.PlayArrow else Icons.Default.Pause,
                                            contentDescription = "Pause/Resume",
                                            tint = FuncPauseAmber
                                        )
                                    }

                                    // Cancel Button triggers confirmation
                                    IconButton(onClick = { taskToCancelId = task.id }) {
                                        Icon(
                                            imageVector = Icons.Default.Cancel,
                                            contentDescription = "Cancel",
                                            tint = FuncCancelRed
                                        )
                                    }
                                }

                                task.errorLog?.let { err ->
                                    TextButton(onClick = { selectedErrorLog = err }) {
                                        Text(text = strings.copyErrorLog, color = FuncCancelRed)
                                    }
                                }
                            }
                        }
                    }
                }

                // Pending Queue
                if (queue.isNotEmpty()) {
                    item {
                        Text(
                            text = "في انتظار التنفيذ (${queue.size}):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }

                    items(queue) { task ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = task.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = task.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { taskToCancelId = task.id }) {
                                    Icon(Icons.Default.Cancel, contentDescription = "Cancel", tint = FuncCancelRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    taskToCancelId?.let { id ->
        ConfirmActionDialog(
            title = strings.confirmCancelTitle,
            message = strings.confirmCancelMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isDestructive = true,
            onConfirm = {
                TaskQueueManager.cancelTask(id)
                taskToCancelId = null
            },
            onDismiss = { taskToCancelId = null }
        )
    }

    selectedErrorLog?.let { err ->
        ErrorLogDialog(
            errorLog = err,
            strings = strings,
            onDismiss = { selectedErrorLog = null }
        )
    }
}
