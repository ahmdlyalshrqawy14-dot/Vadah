package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.i18n.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "voda_user_prefs")

class UserPreferencesRepository(private val context: Context) {

    private val KEY_LANGUAGE = stringPreferencesKey("user_language")
    private val KEY_DARK_THEME = booleanPreferencesKey("user_dark_theme")
    private val KEY_SAF_URI = stringPreferencesKey("user_saf_uri")

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[KEY_LANGUAGE] ?: AppLanguage.ARABIC.code
        if (code == AppLanguage.ENGLISH.code) AppLanguage.ENGLISH else AppLanguage.ARABIC
    }

    val darkThemeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_DARK_THEME] ?: true
    }

    val safUriFlow: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[KEY_SAF_URI]
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LANGUAGE] = language.code
        }
    }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DARK_THEME] = isDark
        }
    }

    suspend fun setSafUri(uriString: String?) {
        context.dataStore.edit { prefs ->
            if (uriString != null) {
                prefs[KEY_SAF_URI] = uriString
            } else {
                prefs.remove(KEY_SAF_URI)
            }
        }
    }
}
