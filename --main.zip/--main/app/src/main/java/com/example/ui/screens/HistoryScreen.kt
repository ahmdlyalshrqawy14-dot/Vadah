package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.core.content.FileProvider
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.data.db.AppDatabase
import com.example.data.i18n.AppStrings
import com.example.processor.ProcessorType
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.ProcessorBadge
import com.example.ui.theme.FuncCancelRed
import com.example.ui.theme.WaterBluePrimary
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    strings: AppStrings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val db = AppDatabase.getDatabase(context)
    val historyItems by db.historyDao().getAllHistory().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var itemToDeleteId by remember { mutableStateOf<Int?>(null) }

    val dateFormat = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault())

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = null,
                    tint = WaterBluePrimary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = strings.history,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = WaterBluePrimary
                )
            }

            if (historyItems.isNotEmpty()) {
                TextButton(onClick = { showClearConfirmDialog = true }) {
                    Text(text = strings.clear, color = FuncCancelRed)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (historyItems.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = strings.noItems,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(historyItems, key = { it.id }) { item ->
                    val file = File(item.outputPath)
                    val exists = file.exists()
                    val pType = if (item.processorType == "HARDWARE") ProcessorType.HARDWARE else ProcessorType.SOFTWARE

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .testTag("history_item_${item.id}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.fileName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                ProcessorBadge(processorType = pType, strings = strings)
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "${item.operationName} • ${dateFormat.format(Date(item.timestamp))}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (item.processedSize > 0) {
                                val formattedSize = Formatter.formatShortFileSize(context, item.processedSize)
                                Text(
                                    text = "الحجم النهائي: $formattedSize",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (exists) {
                                    // Open file
                                    IconButton(
                                        onClick = {
                                            try {
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                                    setDataAndType(uri, context.contentResolver.getType(uri) ?: "*/*")
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                // fallback
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.OpenInNew, contentDescription = "Open File", tint = MaterialTheme.colorScheme.primary)
                                    }

                                    // Share file
                                    IconButton(
                                        onClick = {
                                            try {
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    type = context.contentResolver.getType(uri) ?: "*/*"
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "مشاركة الملف"))
                                            } catch (e: Exception) {
                                                // fallback
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share File", tint = MaterialTheme.colorScheme.secondary)
                                    }
                                }

                                // Delete history record
                                IconButton(onClick = { itemToDeleteId = item.id }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FuncCancelRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirmDialog) {
        ConfirmActionDialog(
            title = strings.confirmClearTitle,
            message = strings.confirmClearMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isDestructive = true,
            onConfirm = {
                scope.launch { db.historyDao().clearAll() }
                showClearConfirmDialog = false
            },
            onDismiss = { showClearConfirmDialog = false }
        )
    }

    itemToDeleteId?.let { id ->
        ConfirmActionDialog(
            title = strings.confirmClearTitle,
            message = strings.confirmClearMessage,
            confirmLabel = strings.confirmBtn,
            cancelLabel = strings.cancelBtn,
            isDestructive = true,
            onConfirm = {
                scope.launch { db.historyDao().deleteById(id) }
                itemToDeleteId = null
            },
            onDismiss = { itemToDeleteId = null }
        )
    }
}
